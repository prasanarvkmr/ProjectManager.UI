import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/app/home/home.component';
import { ProjectComponent } from './project/project.component';
import { TaskComponent } from './task/task.component';
import { UsersComponent } from './users/users.component';
import { ViewTaskComponent } from './view-task/view-task.component';

const routes: Routes = [
  { path: 'project', component: ProjectComponent },
  { path: 'task', component: TaskComponent },
  { path: 'updatetask/:id', component: TaskComponent },
  { path: 'user', component: UsersComponent },
  { path: 'view-task', component: ViewTaskComponent },
  { path: 'view-task/:id', component: ViewTaskComponent }  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
