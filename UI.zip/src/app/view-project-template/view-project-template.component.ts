import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedService } from '../shared.service';
import { Project } from '../model/project';

@Component({
  selector: 'app-view-project-template',
  templateUrl: './view-project-template.component.html',
  styleUrls: ['./view-project-template.component.css']
})
export class ViewProjectTemplateComponent implements OnInit {

  @Input() project: Project;
  
  @Output()
  selectProject = new EventEmitter();

  @Output()
  deleteProject = new EventEmitter();

  constructor(private service : SharedService) { }

  ngOnInit() {
    
  }

  editProject(project: Project) {
    this.project = project;
    this.selectProject.emit(this.project);
  }

  delete(id: number) {    
    this.deleteProject.emit(id);
  }

}
