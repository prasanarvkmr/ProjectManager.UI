import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewProjectTemplateComponent } from './view-project-template.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

describe('ViewProjectTemplateComponent', () => {
  let component: ViewProjectTemplateComponent;
  let fixture: ComponentFixture<ViewProjectTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewProjectTemplateComponent ],
      imports: [ FormsModule, HttpClientModule ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewProjectTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
