import { Component, OnInit, Output, Input } from '@angular/core';
import { Project } from '../model/project';
import { user } from '../model/user';
import { SharedService } from '../shared.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css'],
  providers:[DatePipe]
})
export class AddProjectComponent implements OnInit {

  addProject = new Project();
  Manager = new user();
  model : NgbModalRef;  
  isAdd: boolean;
  isUpdate: boolean;
  closeResult: string;
  error : any = { errorMessage: "", hasErrors : false };
  isSubmit:boolean;  
  modelRef: NgbModalRef;

  @Input()
  set project(project:Project)
  {
    if (project != null) {
      this.isUpdate = true;
      this.isCheckBoxEnabled = project.StartDate != null && project.EndDate != null;

      this.addProject.Id = project.Id;
      this.addProject.Name = project.Name;      
      this.addProject.StartDate = project.StartDate;
      this.addProject.EndDate = project.EndDate;     
      this.addProject.Priority = project.Priority;   

      this.Manager = project.Manager != null ? project.Manager : new user();
      this.ToggleDates();
    }
  }

  @Output()
  projectSubmit = new EventEmitter();

  constructor(private service: SharedService, private modalService: NgbModal, private dateControl : DatePipe) { }

  isCheckBoxEnabled : boolean;

  ngOnInit() {
  }

  openModal(content) {
    this.modelRef = this.modalService.open(content);
    this.modelRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  ToggleDates(){
    if(this.isCheckBoxEnabled)
    {
      var date = new Date();
      var enddate = new Date();
      enddate.setDate(date.getDate() + 1);
      this.addProject.StartDate = this.dateControl.transform(this.isUpdate && this.addProject.StartDate != null ? this.addProject.StartDate : date, "yyyy-MM-dd");
      this.addProject.EndDate = this.dateControl.transform(this.isUpdate && this.addProject.EndDate != null ? this.addProject.EndDate : enddate, "yyyy-MM-dd");
    }
    else{
      this.addProject.StartDate = null;
      this.addProject.EndDate = null;
      this.error = { isError: false, errorMessage: '' };
    }
  }

  DateValidator(): void {

    this.error = { hasErrors: false, errorMessage: '' };

    if (this.isCheckBoxEnabled) {
      if (this.addProject.StartDate.length == 0) {
        this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
      }
      else if (this.addProject.EndDate.length == 0) {
        this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
      }
    }
    if (!this.error.hasErrors) {
      if (new Date(this.addProject.StartDate) > new Date(this.addProject.EndDate)) {
        this.error = { hasErrors: true, errorMessage: 'End Date can not before start date' };
      }
    }
  }
  
  refreshManager(selectedData) {
    //this.model.close();
    this.addProject.UserId = selectedData.id;
    this.Manager.Name = selectedData.value;
    this.Manager.Id = selectedData.id;
    this.closeModal();
  }

  cancelEdit() {
    this.isUpdate = false;
    this.resetForm();
  }

  closeModal() {    
    this.modelRef.close();
  }

  onSubmit()
  {
    this.isSubmit = true;

    let project = {
      Id : this.addProject.Id,
      Name : this.addProject.Name,
      StartDate : this.addProject.StartDate,
      EndDate : this.addProject.EndDate,
      Priority : this.addProject.Priority,
      Manager : this.Manager
    }
    this.service.post("projects", project).subscribe(() => {
      this.resetForm();
      this.projectSubmit.emit();
      if (!this.isUpdate) {
      alert("Project created successfully");
      }else{
        alert("Project updated successfully");
      }
    });
  }
  resetForm() {
    this.addProject = new Project();
    this.Manager = new user();
    this.isCheckBoxEnabled = false;
    this.ToggleDates();
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title', size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

}
