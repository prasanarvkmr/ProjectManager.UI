import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProjectComponent } from './add-project.component';
import { FormsModule }   from '@angular/forms';

import { Component, OnInit, Output, Input } from '@angular/core';
import { Project } from '../model/project';
import { user } from '../model/user';
import { SharedService } from '../shared.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { EventEmitter } from '@angular/core';
import { ModalTemplateComponent } from '../modal-template/modal-template.component';
import { HttpClientModule } from '@angular/common/http';

describe('AddProjectComponent', () => {
  let component: AddProjectComponent;
  let fixture: ComponentFixture<AddProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddProjectComponent, ModalTemplateComponent ],
      imports: [ FormsModule, HttpClientModule ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('start and end dates should be set', () => {
    expect(component.project.StartDate).toBeNull();
    component.ToggleDates();
    expect(component.project.StartDate).not.toBeNull();
  });

  it('Project title field validity', () => {
    let errors = {};
    let projectTitle = component.project.Name;
    errors = projectTitle || {};
    expect(errors['required']).toBeTruthy();
  });
});
