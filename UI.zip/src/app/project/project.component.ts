import { Component, OnInit } from '@angular/core';
import { Project } from '../model/project';
import { SharedService } from '../shared.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {

  constructor(private service : SharedService) { }

  projects: Project[];
  project : Project;
  sortedBy;
  sortedOrder;

  ngOnInit() {
    this.getProjects();
  }

  getProjects() {
    this.service.get<Project[]>("projects").subscribe(data => this.projects = data);
  }

  sortProjects(sortBy: string) {    
    var sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    this.projects = _.orderBy(this.projects, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  searchProjects(searchCriteria) {
    this.service.get<Project[]>("projects", searchCriteria).subscribe(data => { this.projects = data;});
  }

  editProject(project: Project) {
    this.project = project;
  }

  deleteProject(id: number) {    
    this.service.delete("projects", id).subscribe(() => { 
      this.getProjects();  
      alert("Project deleted successfully");
    });
  }

}
