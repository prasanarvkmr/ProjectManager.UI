import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { SharedService } from '../shared.service';
import { user } from '../model/User';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  Manager = new user();
  isUpdate = false;
  submitted = false;

  constructor(private service : SharedService) { }

  ngOnInit() {
  }

  @Output()
  userSubmit = new EventEmitter();
  @Input()
  set user(user) {
      if (user != null) {
        this.isUpdate = true;
        this.Manager = user;
      }
  }
  OnSubmit() {
      this.submitted = true;

      let user = {
        FirstName : this.Manager.FirstName,
        LastName : this.Manager.LastName,
        EmployeeId : this.Manager.EmployeeId,
        Id : this.Manager.Id
      }

      if (!this.isUpdate) {
          this.service.post("users", user)
              .subscribe(() => {
                  this.resetForm();
                  this.userSubmit.emit();
                  alert("User created successfully");
              });
      }
      else {
          this.service.put("users", user)
              .subscribe(() => {
                  this.resetForm();
                  this.userSubmit.emit();
                  this.isUpdate = false;
                  alert("User updated successfully");
              });
      }
  }
  cancelEdit() {
      this.isUpdate = false;
      this.resetForm();
  }
  resetForm() {
      this.submitted = false;
      this.Manager = new user();
  }
  
}
