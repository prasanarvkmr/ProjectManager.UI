import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment.prod';

@Injectable({
  providedIn: 'root'
})

export class SharedService {

  apiUrl : string = "";
  data : any;


  constructor(public service: HttpClient) 
  {
    this.apiUrl = environment.apiUrl;
  }

  get<T>(action: string, criteria?: string): Observable<T> {
    var url = criteria != null && criteria != undefined ? this.apiUrl + action + "/" + criteria : this.apiUrl + action;
    var project = this.service.get<T>(url);    
    return project;
  }

  post(action: string, data: any): Observable<any> {
    var url = this.apiUrl + action;
    var project = this.service.post<any>(url, data);    
    return project;
  }

  put(action: string, data: any): Observable<any> {
    var url = this.apiUrl + action;
    var project = this.service.put<any>(url, data);    
    return project;
  }

  delete(action: string, id: any): Observable<any> {
    var url = this.apiUrl + action + "/" + id;
    var project = this.service.delete<any>(url);    
    return project;
  }
}
