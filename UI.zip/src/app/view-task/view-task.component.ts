import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from '../shared.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Project } from '../model/project';
import { Task } from '../model/task';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {
  modelRef: NgbModalRef;

  constructor(private service: SharedService,
    private modalService: NgbModal,
    private route: ActivatedRoute) { }

  Project = null; 
  modal;
  sortedBy;
  sortedOrder;
  Tasks : Task[];

  ngOnInit() {
    var id = this.route.snapshot.params['id'];
    if (id != null) {
      this.service.get<Project>("projects-id", id).subscribe(data => {
        this.Project = { Id: data[0].Id, Name: data[0].Name };
        this.GetTasks(id);
      });
    }
  }

  openModal(content) {
    this.modelRef = this.modalService.open(content);
    this.modelRef.result.then((result) => {
      //this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  GetTasks(id){
    this.service.get<Project>("projects-id", id).subscribe(value => {
      console.log(value);
      this.Tasks = value[0].Tasks;
    });
  }

  sortTasks(sortBy: string, sortOrder) {
    if (!(sortOrder != null && this.sortedBy != sortBy)) {
      sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    }
    this.Tasks = _.orderBy(this.Tasks, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  endTask(taskId) {
    this.service.delete("delete-task", taskId).subscribe(
      () => {
        alert("Task ended successfully");
        this.GetTasks(this.Project.id);
      });
  }

  ProjectSearch(data){
    this.Project = { Id: data.id, Name: data.value };
    this.GetTasks(data.id);
    this.closeModal();
  }

  closeModal() {
    this.modelRef.close();
  }

}
