import { Component, OnInit } from '@angular/core';
import { user } from '../model/User';
import { SharedService } from '../shared.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  users : user[];
  user :user;
  sortedBy: string;
  sortedOrder: string;

  constructor(private service : SharedService) { }

  ngOnInit() {
    this.GetUsers();
  }

  GetUsers()  {
    this.service.get<user[]>("users").subscribe(data => this.users = data);
  }

  editUser(user: user) {
    this.user = user;    
  }

  deleteUser(id: number) {    
    this.service.delete("users", id).subscribe(() => {        
        this.GetUsers();
        alert("User deleted successfully");        
      });
  }

  sortUsers(sortBy: string) {
    var sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    this.users = _.orderBy(this.users, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  searchUsers(searchText) {
    this.service.get<user[]>("users", searchText).subscribe(data => { this.users = data; });
  }

}
