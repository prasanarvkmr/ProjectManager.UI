import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { SharedService } from 'src/app/shared.service';
import { HttpClientModule } from '@angular/common/http';
import { ProjectComponent } from './project/project.component';
import { TaskComponent } from './task/task.component';
import { UsersComponent } from './users/users.component';
import { ViewTaskComponent } from './view-task/view-task.component';
import { ViewProjectTemplateComponent } from './view-project-template/view-project-template.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { AddUserComponent } from './add-user/add-user.component';
import { ViewTaskTemplateComponent } from './view-task-template/view-task-template.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ModalTemplateComponent } from './modal-template/modal-template.component';
import { DatePipe } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProjectComponent,
    TaskComponent,
    UsersComponent,
    ViewTaskComponent,
    ViewProjectTemplateComponent,
    AddProjectComponent,
    AddTaskComponent,
    AddUserComponent,
    ViewTaskTemplateComponent,
    ViewUserComponent,
    ModalTemplateComponent,
    // DatePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule
    // DatePipe
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
