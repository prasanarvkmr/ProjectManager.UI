import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { user } from '../model/User';
import * as _ from 'lodash';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  sortedBy;
  sortedOrder
  users : user[]; 


  constructor(private service : SharedService) { }

  @Input() user : user;

  @Output()
  selectUser = new EventEmitter();

  @Output()
  deleteUser = new EventEmitter();

  ngOnInit() {
  }

  editUser(user: user) {
    this.user = user;
    this.selectUser.emit(this.user);
  }
  
  delete(id) {
    this.deleteUser.emit(id);
  }
  
}
