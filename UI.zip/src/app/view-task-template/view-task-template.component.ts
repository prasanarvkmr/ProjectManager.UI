import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-task-template',
  templateUrl: './view-task-template.component.html',
  styleUrls: ['./view-task-template.component.css']
})
export class ViewTaskTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
