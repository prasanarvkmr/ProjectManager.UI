import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SharedService } from '../shared.service';
import { forEach } from '@angular/router/src/utils/collection';
import { Project } from '../model/project';
import * as _ from 'lodash';

@Component({
  selector: 'app-modal-template',
  templateUrl: './modal-template.component.html',
  styleUrls: ['./modal-template.component.css']
})

export class ModalTemplateComponent implements OnInit {
  result: { id: number, value: string }[] = [];
  allData: any;
  closeBtnName = "Close";
  apiUrl: string;


  @Input()
  Key: string;
  
  @Output()
  OnDataSelect = new EventEmitter();
  @Output()
  closeClick = new EventEmitter();

  ngOnInit(): void {
    if(this.Key == "User")
    {
      this.apiUrl = "users"
    }
    else if(this.Key == "Project")
    {
      this.apiUrl = "projects"
    }
    else if(this.Key == "Task")
    {
      this.apiUrl = "tasks"
    }
    else if(this.Key == "ParentTask"){
      this.apiUrl = "parenttasks";
    }

    if(this.apiUrl != "" || this.apiUrl != undefined)
    {
        this.service.get<Project[]>(this.apiUrl)
          .subscribe(data => {
            data.forEach(value => {
              this.result.push({ id: value.Id, value: value.Name });
            });
        });
        this.allData = this.result;
    }
  }

  closeResult: string;

  constructor(private service: SharedService) {}  
  searchData(searchText) {
    this.result = _.filter(this.allData,
      (m) => m.value.toLowerCase().indexOf(searchText.toLowerCase()) !== -1)
  }

  selectData(data) {
    this.OnDataSelect.emit(data);
  }

  closeModal() {
    this.closeClick.emit();
  }
}
