import { Task } from "./task";

export class user {
    Id: number;
    FirstName :string;
    LastName :string;
    EmployeeId :number;
    Name: string;
}