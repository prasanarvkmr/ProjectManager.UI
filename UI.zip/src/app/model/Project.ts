import { Task } from "./task";
import { user } from "./User";

export class Project {
    Id: number;
    Name: string;
    Priority: number;
    StartDate: string;
    EndDate: string;    
    UserId: string;

    Manager: user;
    Tasks: Task[];
    tasksCompleted: number;
}