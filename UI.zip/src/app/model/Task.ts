import { Project } from './Project';
import { user } from './User';

export class Task {
    Id: number;
    Name: string;
    Priority: number;
    StartDate?: string;
    EndDate?: string;
    IsParentTask: boolean;    
    IsCompleted: boolean;
    
    ParentId?: number;
    ParentTaskName: string;
    ProjectId: number;
    project: Project;
    ProjectName: string;    
    Manager: user;
}