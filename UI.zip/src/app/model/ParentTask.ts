export class ParentTask {
    Id: number;
    Name: string;
    Priority: number;
    StartDate?: string;
    EndDate?: string;
    IsParentTask: boolean;    
    IsCompleted: boolean;
}