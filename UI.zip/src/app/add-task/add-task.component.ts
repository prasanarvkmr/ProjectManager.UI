import { Component, OnInit } from '@angular/core';
import { NgbModal, NgbModalRef  } from '@ng-bootstrap/ng-bootstrap';
import { Project } from '../model/project';
import { Task } from '../model/task';
import { user } from '../model/user';
import { SharedService } from '../shared.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css'],
  providers:[DatePipe]
})
export class AddTaskComponent implements OnInit {

  isParentTask : boolean;
  Project = new Project();
  Task = new Task();
  Manager = new user();
  Submitted : boolean;
  isUpdate : boolean;
  error : any = { errorMessage: "", hasErrors : false };
  modelRef : NgbModalRef ;

  constructor(private modalService: NgbModal, 
    private service : SharedService,
    private router: Router,
    private route: ActivatedRoute,
    private dateControl: DatePipe) { }

  ngOnInit() {
    this.ToggleDates();
    if (this.route.snapshot.params['id'] != null) {
      this.isUpdate = true;
      this.GetTask(this.route.snapshot.params['id']);
    }    
  }

  GetTask(id){
    this.service.get<Task>("task", id).subscribe(value => {
      console.log(value);
      this.Task = value;
      this.Project.Name = value.ProjectName;
      this.Project.Id = value.ProjectId;
      this.Manager = value.Manager != null ? value.Manager : new user();;
      this.ToggleDates();
    });
  }

  ToggleDates(){
    if(!this.isParentTask)
    {
      var date = new Date();
      var enddate = new Date();
      enddate.setDate(date.getDate() + 1);
      this.Task.StartDate = this.dateControl.transform(this.isUpdate ? this.Task.StartDate : date, "yyyy-MM-dd");
      this.Task.EndDate = this.dateControl.transform(this.isUpdate ? this.Task.EndDate : enddate, "yyyy-MM-dd");
    }
    else{
      this.Task.StartDate = null;
      this.Task.EndDate = null;
      this.Task.ParentId = null;
      this.Task.ParentTaskName = null;
      this.Manager.Id = 0;
      this.Manager.Name = null
      this.error = { isError: false, errorMessage: '' };
    }
  }

  closeResult;

  openModal(content) {
    this.modelRef = this.modalService.open(content);
    this.modelRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  refreshProject(selectedData){
    this.Project.Name = selectedData.value;    
    this.Project.Id = selectedData.id;
    this.closeModal();
  }

  refreshParentTask(selectedData){
    this.Task.ParentId = selectedData.id;
    this.Task.ParentTaskName = selectedData.value;
    this.closeModal();
  }

  refreshUser(selectedData){
    this.Manager.Id = selectedData.id;
    this.Manager.Name = selectedData.value;
    this.closeModal();
  }

  DateValidator(): void {

    this.error = { hasErrors: false, errorMessage: '' };

    if (this.Task.StartDate.length == 0) {
      this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
    }
    else if (this.Task.EndDate.length == 0) {
      this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
    }
    if (!this.error.hasErrors) {
      if (new Date(this.Task.StartDate) > new Date(this.Task.EndDate)) {
        this.error = { hasErrors: true, errorMessage: 'End Date can not before start date' };
      }
    }
  }

  onSubmit()
  {
    console.log(this.Project);
    console.log(this.Manager);
    console.log(this.Task);
    this.Submitted = true;

    let Task = {
      ParentId : this.Task.ParentId,
      ParentTaskName : this.Task.ParentTaskName,
      Id : this.Task.Id,
      Task : this.Task.Name,
      Name : this.Task.Name,
      StartDate: this.Task.StartDate,
      EndDate : this.Task.EndDate,
      Priority: this.Task.Priority,
      IsParentTask: this.isParentTask,
      ProjectId: this.Project.Id,
      Manager: this.Manager
    };
    
    if (!this.isUpdate) {
      this.service.post("tasks", Task)
        .subscribe(() => {
          alert("Task created successfully");
          this.router.navigate(["/view-task", this.Project.Id]);
        });
    }
    else {
      this.service.put("tasks", Task)
        .subscribe(() => {
          alert("Task updated successfully");
          this.router.navigate(["/view-task", this.Project.Id]);
        });
    }
  }

  closeModal() {    
    this.modelRef.close();
  }

  ResetForm(){
    this.Task = new Task();
    this.isParentTask = false;
    this.Manager = new user();    
  }

}
